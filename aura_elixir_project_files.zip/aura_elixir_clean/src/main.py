from flask import Flask
from src.models.models import db
from src.routes.main import main_bp
from src.routes.auth import auth_bp
from src.routes.product import product_bp
from src.routes.cart import cart_bp
from src.routes.account import account_bp
import os

def create_app():
    app = Flask(__name__)
    app.secret_key = 'aura_elixir_secret_key'
    
    # تكوين قاعدة البيانات
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///aura_elixir.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    # تهيئة قاعدة البيانات
    db.init_app(app)
    
    # تسجيل المسارات
    app.register_blueprint(main_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(product_bp)
    app.register_blueprint(cart_bp)
    app.register_blueprint(account_bp)
    
    # إنشاء جميع الجداول في قاعدة البيانات
    with app.app_context():
        db.create_all()
        
        # إضافة بيانات تجريبية إذا كانت قاعدة البيانات فارغة
        from src.models.models import Category, Product, User
        from werkzeug.security import generate_password_hash
        
        if not Category.query.first():
            # إضافة فئات
            categories = [
                Category(name='عطور رجالية', description='مجموعة مختارة من أفخم العطور الرجالية', image='category-men.jpg'),
                Category(name='عطور نسائية', description='تشكيلة راقية من العطور النسائية الفاخرة', image='category-women.jpg'),
                Category(name='عطور للجنسين', description='عطور مميزة تناسب جميع الأذواق', image='category-unisex.jpg'),
                Category(name='تركيبات خاصة', description='عطور مصممة خصيصاً لتناسب شخصيتك', image='category-custom.jpg')
            ]
            db.session.add_all(categories)
            db.session.commit()
            
            # إضافة منتجات
            products = [
                Product(name='عطر الصحراء الملكي', description='عطر فاخر بمزيج من العود والمسك والعنبر', price=750, image='product1.jpg', category_id=1, stock=50),
                Product(name='مسك الليل', description='عطر مميز بنفحات المسك والفانيليا', price=850, image='product2.jpg', category_id=2, stock=40),
                Product(name='أريج الزهور', description='عطر منعش بمزيج من الزهور والفواكه', price=600, image='product3.jpg', category_id=2, stock=60),
                Product(name='عبير الشرق', description='عطر شرقي فاخر بنفحات العود والبخور', price=920, image='product4.jpg', category_id=3, stock=30),
                Product(name='نسيم الصباح', description='عطر منعش بنفحات الحمضيات والأزهار', price=550, image='product5.jpg', category_id=3, stock=45),
                Product(name='سحر الشرق', description='تركيبة خاصة من أجود أنواع العطور الشرقية', price=1200, image='product6.jpg', category_id=4, stock=20),
                Product(name='عطر الأمراء', description='عطر فاخر مستوحى من العطور الملكية', price=980, image='product7.jpg', category_id=1, stock=35),
                Product(name='روح الياسمين', description='عطر ناعم بنفحات الياسمين والورد', price=720, image='product8.jpg', category_id=2, stock=55)
            ]
            db.session.add_all(products)
            db.session.commit()
            
            # إضافة مستخدم تجريبي
            admin_user = User(
                username='admin',
                email='admin@auraelixir.com',
                password_hash=generate_password_hash('admin123'),
                first_name='مدير',
                last_name='النظام',
                phone='0123456789'
            )
            db.session.add(admin_user)
            db.session.commit()
    
    return app

if __name__ == '__main__':
    app = create_app()
    app.run(host='0.0.0.0', port=5000, debug=True)
