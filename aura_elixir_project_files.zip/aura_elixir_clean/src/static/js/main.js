// الوظائف الرئيسية للمتجر
document.addEventListener('DOMContentLoaded', function() {
    // تحديث عدد العناصر في عربة التسوق
    updateCartCount();
    
    // تفعيل صور المنتج المصغرة في صفحة تفاصيل المنتج
    initProductThumbnails();
    
    // تفعيل التبديل بين أقسام الحساب الشخصي
    initAccountTabs();
});

// تحديث عدد العناصر في عربة التسوق
function updateCartCount() {
    // هذه الوظيفة ستستبدل بطلب AJAX للحصول على عدد العناصر الفعلي من الخادم
    const cartCount = localStorage.getItem('cartCount') || 0;
    const cartCountElements = document.querySelectorAll('.cart-count');
    cartCountElements.forEach(element => {
        element.textContent = cartCount;
    });
}

// إضافة منتج إلى عربة التسوق
function addToCart(productId, quantity = 1) {
    // هذه الوظيفة ستستبدل بطلب AJAX لإضافة المنتج إلى عربة التسوق في الخادم
    let cartCount = parseInt(localStorage.getItem('cartCount') || 0);
    cartCount += parseInt(quantity);
    localStorage.setItem('cartCount', cartCount);
    
    // تحديث عدد العناصر في عربة التسوق
    updateCartCount();
    
    // عرض رسالة تأكيد
    showNotification('تمت إضافة المنتج إلى عربة التسوق');
}

// عرض إشعار للمستخدم
function showNotification(message) {
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // إظهار الإشعار
    setTimeout(() => {
        notification.classList.add('show');
    }, 10);
    
    // إخفاء الإشعار بعد 3 ثوانٍ
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// تفعيل صور المنتج المصغرة في صفحة تفاصيل المنتج
function initProductThumbnails() {
    const thumbnails = document.querySelectorAll('.product-thumbnail');
    const mainImage = document.querySelector('.product-main-image img');
    
    if (thumbnails.length && mainImage) {
        thumbnails.forEach(thumbnail => {
            thumbnail.addEventListener('click', function() {
                // إزالة الفئة النشطة من جميع الصور المصغرة
                thumbnails.forEach(thumb => {
                    thumb.classList.remove('active');
                });
                
                // إضافة الفئة النشطة للصورة المصغرة المحددة
                this.classList.add('active');
                
                // تحديث الصورة الرئيسية
                const thumbnailImg = this.querySelector('img');
                mainImage.src = thumbnailImg.src;
                mainImage.alt = thumbnailImg.alt;
            });
        });
    }
}

// تفعيل التبديل بين أقسام الحساب الشخصي
function initAccountTabs() {
    const menuItems = document.querySelectorAll('.account-menu li a');
    const sections = document.querySelectorAll('.account-section');
    
    if (menuItems.length && sections.length) {
        menuItems.forEach(item => {
            item.addEventListener('click', function(e) {
                e.preventDefault();
                
                // إزالة الفئة النشطة من جميع عناصر القائمة
                menuItems.forEach(menuItem => {
                    menuItem.parentElement.classList.remove('active');
                });
                
                // إضافة الفئة النشطة للعنصر المحدد
                this.parentElement.classList.add('active');
                
                // إخفاء جميع الأقسام
                sections.forEach(section => {
                    section.style.display = 'none';
                });
                
                // إظهار القسم المحدد
                const targetId = this.getAttribute('href').substring(1);
                document.getElementById(targetId).style.display = 'block';
            });
        });
    }
}

// زيادة كمية المنتج
function increaseQuantity(inputId = 'quantity') {
    const quantityInput = document.getElementById(inputId);
    if (quantityInput) {
        let value = parseInt(quantityInput.value);
        quantityInput.value = value + 1;
    }
}

// تقليل كمية المنتج
function decreaseQuantity(inputId = 'quantity') {
    const quantityInput = document.getElementById(inputId);
    if (quantityInput) {
        let value = parseInt(quantityInput.value);
        if (value > 1) {
            quantityInput.value = value - 1;
        }
    }
}

// تحديث كمية المنتج في عربة التسوق
function updateQuantity(itemId, action) {
    const quantityInput = document.getElementById('quantity-' + itemId);
    if (quantityInput) {
        let currentQuantity = parseInt(quantityInput.value);
        
        if (action === 'increase') {
            quantityInput.value = currentQuantity + 1;
        } else if (action === 'decrease' && currentQuantity > 1) {
            quantityInput.value = currentQuantity - 1;
        }
        
        // هذه الوظيفة ستستبدل بطلب AJAX لتحديث الكمية في الخادم
        // وتحديث المجموع الفرعي والإجمالي
    }
}

// إزالة منتج من عربة التسوق
function removeItem(itemId) {
    if (confirm('هل أنت متأكد من رغبتك في إزالة هذا المنتج من عربة التسوق؟')) {
        // هذه الوظيفة ستستبدل بطلب AJAX لإزالة المنتج من عربة التسوق في الخادم
        // وتحديث الصفحة
    }
}

// فرز المنتجات في صفحة الفئات
function sortProducts(value) {
    // إعادة تحميل الصفحة مع معلمة الفرز
    window.location.href = window.location.pathname + '?sort=' + value;
}

// تصفية المنتجات حسب السعر في صفحة الفئات
function filterByPrice(value) {
    const priceValueElement = document.getElementById('price-value');
    if (priceValueElement) {
        priceValueElement.textContent = value + ' ريال';
    }
    
    // إعادة تحميل الصفحة مع معلمة نطاق السعر
    window.location.href = window.location.pathname + '?max_price=' + value;
}
