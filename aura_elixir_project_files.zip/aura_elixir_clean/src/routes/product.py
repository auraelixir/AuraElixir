from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from src.models.models import db, Product, Category, Review, User

product_bp = Blueprint('product', __name__)

@product_bp.route('/categories')
def categories():
    # الحصول على جميع الفئات
    all_categories = Category.query.all()
    
    return render_template('categories.html', categories=all_categories)

@product_bp.route('/categories/<int:category_id>')
def category_products(category_id):
    # الحصول على الفئة المحددة
    category = Category.query.get_or_404(category_id)
    
    # الحصول على معلمات التصفية والفرز
    sort = request.args.get('sort', 'default')
    max_price = request.args.get('max_price', 2000, type=float)
    page = request.args.get('page', 1, type=int)
    per_page = 8  # عدد المنتجات في كل صفحة
    
    # استعلام المنتجات مع التصفية والفرز
    products_query = Product.query.filter_by(category_id=category_id).filter(Product.price <= max_price)
    
    if sort == 'price-asc':
        products_query = products_query.order_by(Product.price)
    elif sort == 'price-desc':
        products_query = products_query.order_by(Product.price.desc())
    elif sort == 'rating-desc':
        # هذا تقريبي، لأن التقييم هو خاصية محسوبة
        products_query = products_query.order_by(Product.id.desc())
    elif sort == 'newest':
        products_query = products_query.order_by(Product.created_at.desc())
    
    # تقسيم الصفحات
    products_pagination = products_query.paginate(page=page, per_page=per_page)
    products = products_pagination.items
    
    return render_template('categories.html', 
                          categories=Category.query.all(),
                          selected_category=category,
                          products=products,
                          current_page=page,
                          pages=products_pagination.pages)

@product_bp.route('/product/<int:product_id>')
def detail(product_id):
    # الحصول على المنتج المحدد
    product = Product.query.get_or_404(product_id)
    
    # الحصول على تقييمات المنتج
    reviews = Review.query.filter_by(product_id=product_id).order_by(Review.created_at.desc()).all()
    
    # الحصول على منتجات مشابهة
    similar_products = Product.query.filter_by(category_id=product.category_id).filter(Product.id != product_id).limit(4).all()
    
    return render_template('product.html', product=product, reviews=reviews, similar_products=similar_products)

@product_bp.route('/product/<int:product_id>/review', methods=['POST'])
def add_review(product_id):
    # التحقق من تسجيل دخول المستخدم
    if 'user_id' not in session:
        flash('يرجى تسجيل الدخول لإضافة تقييم', 'error')
        return redirect(url_for('auth.login'))
    
    # الحصول على بيانات التقييم
    rating = request.form.get('rating', type=int)
    comment = request.form.get('comment')
    
    # التحقق من صحة البيانات
    if not rating or rating < 1 or rating > 5:
        flash('يرجى تحديد تقييم صحيح', 'error')
        return redirect(url_for('product.detail', product_id=product_id))
    
    # إنشاء تقييم جديد
    review = Review(
        product_id=product_id,
        user_id=session['user_id'],
        rating=rating,
        comment=comment
    )
    
    # حفظ التقييم في قاعدة البيانات
    db.session.add(review)
    db.session.commit()
    
    flash('تم إضافة تقييمك بنجاح', 'success')
    return redirect(url_for('product.detail', product_id=product_id))
