from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from src.models.models import db, Product, Category, Review, User
from werkzeug.security import check_password_hash

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        # التحقق من صحة البيانات
        if not email or not password:
            flash('يرجى ملء جميع الحقول المطلوبة', 'error')
            return redirect(url_for('auth.login'))
        
        # البحث عن المستخدم
        user = User.query.filter_by(email=email).first()
        
        # التحقق من وجود المستخدم وصحة كلمة المرور
        if not user or not check_password_hash(user.password_hash, password):
            flash('البريد الإلكتروني أو كلمة المرور غير صحيحة', 'error')
            return redirect(url_for('auth.login'))
        
        # تسجيل دخول المستخدم
        session['user_id'] = user.id
        session['username'] = user.username
        
        flash('تم تسجيل الدخول بنجاح', 'success')
        return redirect(url_for('main.index'))
    
    return render_template('login.html')

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        first_name = request.form.get('first_name')
        last_name = request.form.get('last_name')
        phone = request.form.get('phone')
        
        # التحقق من صحة البيانات
        if not all([username, email, password, confirm_password, first_name, last_name, phone]):
            flash('يرجى ملء جميع الحقول المطلوبة', 'error')
            return redirect(url_for('auth.register'))
        
        if password != confirm_password:
            flash('كلمات المرور غير متطابقة', 'error')
            return redirect(url_for('auth.register'))
        
        # التحقق من عدم وجود مستخدم بنفس اسم المستخدم أو البريد الإلكتروني
        if User.query.filter_by(username=username).first():
            flash('اسم المستخدم مستخدم بالفعل', 'error')
            return redirect(url_for('auth.register'))
        
        if User.query.filter_by(email=email).first():
            flash('البريد الإلكتروني مستخدم بالفعل', 'error')
            return redirect(url_for('auth.register'))
        
        # إنشاء مستخدم جديد
        user = User(
            username=username,
            email=email,
            password_hash=generate_password_hash(password),
            first_name=first_name,
            last_name=last_name,
            phone=phone
        )
        
        # حفظ المستخدم في قاعدة البيانات
        db.session.add(user)
        db.session.commit()
        
        flash('تم إنشاء حسابك بنجاح، يمكنك الآن تسجيل الدخول', 'success')
        return redirect(url_for('auth.login'))
    
    return render_template('register.html')

@auth_bp.route('/logout')
def logout():
    # مسح بيانات الجلسة
    session.pop('user_id', None)
    session.pop('username', None)
    
    flash('تم تسجيل الخروج بنجاح', 'success')
    return redirect(url_for('main.index'))
