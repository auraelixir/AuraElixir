from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from src.models.models import db, Category, Product

main_bp = Blueprint('main', __name__)

@main_bp.route('/')
def index():
    # الحصول على الفئات
    categories = Category.query.all()
    
    # الحصول على المنتجات المميزة
    featured_products = Product.query.order_by(Product.created_at.desc()).limit(4).all()
    
    return render_template('index.html', categories=categories, featured_products=featured_products)

@main_bp.route('/about')
def about():
    return render_template('about.html')

@main_bp.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        subject = request.form.get('subject')
        message = request.form.get('message')
        
        # التحقق من صحة البيانات
        if not all([name, email, subject, message]):
            flash('يرجى ملء جميع الحقول المطلوبة', 'error')
            return redirect(url_for('main.contact'))
        
        # هنا يمكن إضافة كود لإرسال رسالة بريد إلكتروني أو حفظ الرسالة في قاعدة البيانات
        
        flash('تم إرسال رسالتك بنجاح، سنتواصل معك قريباً', 'success')
        return redirect(url_for('main.contact'))
    
    return render_template('contact.html')
