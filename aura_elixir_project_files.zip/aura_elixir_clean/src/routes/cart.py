from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from src.models.models import db, Product, Category, Review, Order, OrderDetail

cart_bp = Blueprint('cart', __name__)

@cart_bp.route('/cart')
def view_cart():
    cart_items = []
    subtotal = 0
    shipping = 0
    total = 0
    
    # التحقق من وجود عربة تسوق في الجلسة
    if 'cart' in session:
        # الحصول على معرفات المنتجات والكميات من الجلسة
        cart_data = session['cart']
        
        # الحصول على معلومات المنتجات من قاعدة البيانات
        for product_id, quantity in cart_data.items():
            product = Product.query.get(int(product_id))
            if product:
                item_subtotal = product.price * quantity
                cart_items.append({
                    'id': product.id,
                    'name': product.name,
                    'price': product.price,
                    'image': product.image,
                    'quantity': quantity,
                    'subtotal': item_subtotal
                })
                subtotal += item_subtotal
        
        # حساب الشحن والإجمالي
        shipping = 30 if subtotal > 0 else 0
        total = subtotal + shipping
    
    return render_template('cart.html', cart_items=cart_items, subtotal=subtotal, shipping=shipping, total=total)

@cart_bp.route('/add-to-cart/<int:product_id>', methods=['POST'])
def add_to_cart(product_id):
    # الحصول على الكمية من النموذج
    quantity = request.form.get('quantity', 1, type=int)
    
    # التحقق من وجود المنتج
    product = Product.query.get_or_404(product_id)
    
    # التحقق من توفر الكمية المطلوبة
    if product.stock < quantity:
        flash('الكمية المطلوبة غير متوفرة', 'error')
        return redirect(url_for('product.detail', product_id=product_id))
    
    # إنشاء أو تحديث عربة التسوق في الجلسة
    if 'cart' not in session:
        session['cart'] = {}
    
    # إضافة المنتج إلى عربة التسوق أو تحديث الكمية
    cart = session['cart']
    product_id_str = str(product_id)
    
    if product_id_str in cart:
        cart[product_id_str] += quantity
    else:
        cart[product_id_str] = quantity
    
    session['cart'] = cart
    
    flash('تمت إضافة المنتج إلى عربة التسوق', 'success')
    return redirect(url_for('cart.view_cart'))

@cart_bp.route('/update-cart', methods=['POST'])
def update_cart():
    # الحصول على بيانات التحديث
    product_id = request.form.get('product_id')
    quantity = request.form.get('quantity', 1, type=int)
    action = request.form.get('action')
    
    # التحقق من وجود عربة تسوق في الجلسة
    if 'cart' not in session:
        return jsonify({'success': False, 'message': 'عربة التسوق فارغة'})
    
    cart = session['cart']
    
    # تحديث الكمية أو إزالة المنتج
    if action == 'update':
        if product_id in cart:
            cart[product_id] = quantity
    elif action == 'remove':
        if product_id in cart:
            del cart[product_id]
    
    session['cart'] = cart
    
    return jsonify({'success': True})

@cart_bp.route('/checkout')
def checkout():
    # التحقق من وجود عناصر في عربة التسوق
    if 'cart' not in session or not session['cart']:
        flash('عربة التسوق فارغة', 'error')
        return redirect(url_for('cart.view_cart'))
    
    # التحقق من تسجيل دخول المستخدم
    if 'user_id' not in session:
        flash('يرجى تسجيل الدخول لإتمام الطلب', 'error')
        return redirect(url_for('auth.login'))
    
    # الحصول على معلومات المستخدم
    user = User.query.get(session['user_id'])
    
    # الحصول على عناوين المستخدم
    addresses = Address.query.filter_by(user_id=session['user_id']).all()
    
    # حساب المجموع الفرعي والشحن والإجمالي
    cart_items = []
    subtotal = 0
    
    cart_data = session['cart']
    for product_id, quantity in cart_data.items():
        product = Product.query.get(int(product_id))
        if product:
            item_subtotal = product.price * quantity
            cart_items.append({
                'id': product.id,
                'name': product.name,
                'price': product.price,
                'image': product.image,
                'quantity': quantity,
                'subtotal': item_subtotal
            })
            subtotal += item_subtotal
    
    shipping = 30 if subtotal > 0 else 0
    total = subtotal + shipping
    
    return render_template('checkout.html', user=user, addresses=addresses, cart_items=cart_items, subtotal=subtotal, shipping=shipping, total=total)

@cart_bp.route('/place-order', methods=['POST'])
def place_order():
    # التحقق من وجود عناصر في عربة التسوق
    if 'cart' not in session or not session['cart']:
        flash('عربة التسوق فارغة', 'error')
        return redirect(url_for('cart.view_cart'))
    
    # التحقق من تسجيل دخول المستخدم
    if 'user_id' not in session:
        flash('يرجى تسجيل الدخول لإتمام الطلب', 'error')
        return redirect(url_for('auth.login'))
    
    # الحصول على بيانات الطلب
    first_name = request.form.get('first_name')
    last_name = request.form.get('last_name')
    email = request.form.get('email')
    phone = request.form.get('phone')
    address = request.form.get('address')
    city = request.form.get('city')
    postal_code = request.form.get('postal_code')
    payment_method = request.form.get('payment_method', 'mobp')
    
    # التحقق من صحة البيانات
    if not all([first_name, last_name, email, phone, address, city, postal_code]):
        flash('يرجى ملء جميع الحقول المطلوبة', 'error')
        return redirect(url_for('cart.checkout'))
    
    # حساب المجموع الفرعي والشحن والإجمالي
    cart_items = []
    subtotal = 0
    
    cart_data = session['cart']
    for product_id, quantity in cart_data.items():
        product = Product.query.get(int(product_id))
        if product:
            item_subtotal = product.price * quantity
            cart_items.append({
                'id': product.id,
                'price': product.price,
                'quantity': quantity
            })
            subtotal += item_subtotal
    
    shipping = 30 if subtotal > 0 else 0
    total = subtotal + shipping
    
    # إنشاء عنوان الشحن
    shipping_address = f"{first_name} {last_name}\n{address}\n{city}, {postal_code}\n{phone}"
    
    # إنشاء طلب جديد
    order = Order(
        user_id=session['user_id'],
        total_amount=total,
        payment_method=payment_method,
        shipping_address=shipping_address
    )
    
    db.session.add(order)
    db.session.flush()  # للحصول على معرف الطلب
    
    # إضافة تفاصيل الطلب
    for item in cart_items:
        order_detail = OrderDetail(
            order_id=order.id,
            product_id=item['id'],
            quantity=item['quantity'],
            price=item['price']
        )
        db.session.add(order_detail)
    
    # حفظ الطلب في قاعدة البيانات
    db.session.commit()
    
    # مسح عربة التسوق
    session.pop('cart', None)
    
    flash('تم إنشاء طلبك بنجاح', 'success')
    return redirect(url_for('cart.order_confirmation', order_id=order.id))

@cart_bp.route('/order-confirmation/<int:order_id>')
def order_confirmation(order_id):
    # التحقق من تسجيل دخول المستخدم
    if 'user_id' not in session:
        flash('يرجى تسجيل الدخول لعرض تأكيد الطلب', 'error')
        return redirect(url_for('auth.login'))
    
    # الحصول على الطلب
    order = Order.query.filter_by(id=order_id, user_id=session['user_id']).first_or_404()
    
    return render_template('order_confirmation.html', order=order)
