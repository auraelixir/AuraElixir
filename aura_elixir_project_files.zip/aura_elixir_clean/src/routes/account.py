from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from src.models.models import db, User, Order, Address
from werkzeug.security import generate_password_hash, check_password_hash

account_bp = Blueprint('account', __name__)

@account_bp.route('/account')
def view_account():
    # التحقق من تسجيل دخول المستخدم
    if 'user_id' not in session:
        flash('يرجى تسجيل الدخول لعرض حسابك الشخصي', 'error')
        return redirect(url_for('auth.login'))
    
    # الحصول على معلومات المستخدم
    user = User.query.get(session['user_id'])
    
    # الحصول على طلبات المستخدم
    orders = Order.query.filter_by(user_id=session['user_id']).order_by(Order.created_at.desc()).all()
    
    # الحصول على عناوين المستخدم
    addresses = Address.query.filter_by(user_id=session['user_id']).all()
    
    return render_template('account.html', user=user, orders=orders, addresses=addresses)

@account_bp.route('/account/update-profile', methods=['POST'])
def update_profile():
    # التحقق من تسجيل دخول المستخدم
    if 'user_id' not in session:
        flash('يرجى تسجيل الدخول لتحديث حسابك الشخصي', 'error')
        return redirect(url_for('auth.login'))
    
    # الحصول على بيانات التحديث
    first_name = request.form.get('first_name')
    last_name = request.form.get('last_name')
    email = request.form.get('email')
    phone = request.form.get('phone')
    
    # التحقق من صحة البيانات
    if not all([first_name, last_name, email, phone]):
        flash('يرجى ملء جميع الحقول المطلوبة', 'error')
        return redirect(url_for('account.view_account'))
    
    # الحصول على المستخدم
    user = User.query.get(session['user_id'])
    
    # التحقق من عدم وجود مستخدم آخر بنفس البريد الإلكتروني
    if email != user.email and User.query.filter_by(email=email).first():
        flash('البريد الإلكتروني مستخدم بالفعل', 'error')
        return redirect(url_for('account.view_account'))
    
    # تحديث بيانات المستخدم
    user.first_name = first_name
    user.last_name = last_name
    user.email = email
    user.phone = phone
    
    # حفظ التغييرات في قاعدة البيانات
    db.session.commit()
    
    flash('تم تحديث بياناتك الشخصية بنجاح', 'success')
    return redirect(url_for('account.view_account'))

@account_bp.route('/account/change-password', methods=['POST'])
def change_password():
    # التحقق من تسجيل دخول المستخدم
    if 'user_id' not in session:
        flash('يرجى تسجيل الدخول لتغيير كلمة المرور', 'error')
        return redirect(url_for('auth.login'))
    
    # الحصول على بيانات تغيير كلمة المرور
    current_password = request.form.get('current_password')
    new_password = request.form.get('new_password')
    confirm_password = request.form.get('confirm_password')
    
    # التحقق من صحة البيانات
    if not all([current_password, new_password, confirm_password]):
        flash('يرجى ملء جميع الحقول المطلوبة', 'error')
        return redirect(url_for('account.view_account'))
    
    if new_password != confirm_password:
        flash('كلمات المرور الجديدة غير متطابقة', 'error')
        return redirect(url_for('account.view_account'))
    
    # الحصول على المستخدم
    user = User.query.get(session['user_id'])
    
    # التحقق من صحة كلمة المرور الحالية
    if not check_password_hash(user.password_hash, current_password):
        flash('كلمة المرور الحالية غير صحيحة', 'error')
        return redirect(url_for('account.view_account'))
    
    # تحديث كلمة المرور
    user.password_hash = generate_password_hash(new_password)
    
    # حفظ التغييرات في قاعدة البيانات
    db.session.commit()
    
    flash('تم تغيير كلمة المرور بنجاح', 'success')
    return redirect(url_for('account.view_account'))

@account_bp.route('/account/add-address', methods=['GET', 'POST'])
def add_address():
    # التحقق من تسجيل دخول المستخدم
    if 'user_id' not in session:
        flash('يرجى تسجيل الدخول لإضافة عنوان', 'error')
        return redirect(url_for('auth.login'))
    
    if request.method == 'POST':
        # الحصول على بيانات العنوان
        title = request.form.get('title')
        full_name = request.form.get('full_name')
        street = request.form.get('street')
        city = request.form.get('city')
        postal_code = request.form.get('postal_code')
        phone = request.form.get('phone')
        is_default = request.form.get('is_default') == 'on'
        
        # التحقق من صحة البيانات
        if not all([title, full_name, street, city, postal_code, phone]):
            flash('يرجى ملء جميع الحقول المطلوبة', 'error')
            return redirect(url_for('account.add_address'))
        
        # إذا كان العنوان افتراضياً، قم بإلغاء تعيين العناوين الافتراضية الأخرى
        if is_default:
            Address.query.filter_by(user_id=session['user_id'], is_default=True).update({'is_default': False})
        
        # إنشاء عنوان جديد
        address = Address(
            user_id=session['user_id'],
            title=title,
            full_name=full_name,
            street=street,
            city=city,
            postal_code=postal_code,
            phone=phone,
            is_default=is_default
        )
        
        # حفظ العنوان في قاعدة البيانات
        db.session.add(address)
        db.session.commit()
        
        flash('تمت إضافة العنوان بنجاح', 'success')
        return redirect(url_for('account.view_account'))
    
    return render_template('add_address.html')

@account_bp.route('/account/edit-address/<int:address_id>', methods=['GET', 'POST'])
def edit_address(address_id):
    # التحقق من تسجيل دخول المستخدم
    if 'user_id' not in session:
        flash('يرجى تسجيل الدخول لتعديل العنوان', 'error')
        return redirect(url_for('auth.login'))
    
    # الحصول على العنوان
    address = Address.query.filter_by(id=address_id, user_id=session['user_id']).first_or_404()
    
    if request.method == 'POST':
        # الحصول على بيانات العنوان
        title = request.form.get('title')
        full_name = request.form.get('full_name')
        street = request.form.get('street')
        city = request.form.get('city')
        postal_code = request.form.get('postal_code')
        phone = request.form.get('phone')
        is_default = request.form.get('is_default') == 'on'
        
        # التحقق من صحة البيانات
        if not all([title, full_name, street, city, postal_code, phone]):
            flash('يرجى ملء جميع الحقول المطلوبة', 'error')
            return redirect(url_for('account.edit_address', address_id=address_id))
        
        # إذا كان العنوان افتراضياً، قم بإلغاء تعيين العناوين الافتراضية الأخرى
        if is_default and not address.is_default:
            Address.query.filter_by(user_id=session['user_id'], is_default=True).update({'is_default': False})
        
        # تحديث بيانات العنوان
        address.title = title
        address.full_name = full_name
        address.street = street
        address.city = city
        address.postal_code = postal_code
        address.phone = phone
        address.is_default = is_default
        
        # حفظ التغييرات في قاعدة البيانات
        db.session.commit()
        
        flash('تم تحديث العنوان بنجاح', 'success')
        return redirect(url_for('account.view_account'))
    
    return render_template('edit_address.html', address=address)

@account_bp.route('/account/delete-address/<int:address_id>')
def delete_address(address_id):
    # التحقق من تسجيل دخول المستخدم
    if 'user_id' not in session:
        flash('يرجى تسجيل الدخول لحذف العنوان', 'error')
        return redirect(url_for('auth.login'))
    
    # الحصول على العنوان
    address = Address.query.filter_by(id=address_id, user_id=session['user_id']).first_or_404()
    
    # حذف العنوان
    db.session.delete(address)
    db.session.commit()
    
    flash('تم حذف العنوان بنجاح', 'success')
    return redirect(url_for('account.view_account'))

@account_bp.route('/account/set-default-address/<int:address_id>')
def set_default_address(address_id):
    # التحقق من تسجيل دخول المستخدم
    if 'user_id' not in session:
        flash('يرجى تسجيل الدخول لتعيين العنوان الافتراضي', 'error')
        return redirect(url_for('auth.login'))
    
    # الحصول على العنوان
    address = Address.query.filter_by(id=address_id, user_id=session['user_id']).first_or_404()
    
    # إلغاء تعيين العناوين الافتراضية الأخرى
    Address.query.filter_by(user_id=session['user_id'], is_default=True).update({'is_default': False})
    
    # تعيين العنوان كافتراضي
    address.is_default = True
    db.session.commit()
    
    flash('تم تعيين العنوان كافتراضي بنجاح', 'success')
    return redirect(url_for('account.view_account'))
